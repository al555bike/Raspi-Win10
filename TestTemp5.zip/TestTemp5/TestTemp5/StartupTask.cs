﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using Windows.Devices.Enumeration;
using Windows.Devices.SerialCommunication;

using Windows.ApplicationModel.Background;

// The Background Application template is documented at http://go.microsoft.com/fwlink/?LinkID=533884&clcid=0x409

namespace TestTemp5
{
    public sealed class StartupTask : IBackgroundTask
    {

        private string deviceId = string.Empty;
        private Timer tmr;
        private OneWire dsTemp;

        public void Run(IBackgroundTaskInstance taskInstance)
        {
            // 
            // TODO: Insert code to perform background work
            //
            // If you start any asynchronous methods here, prevent the task
            // from closing prematurely by using BackgroundTaskDeferral as
            // described in http://aka.ms/backgroundtaskdeferral

            dsTemp = new OneWire();
            deviceId = string.Empty;
            tmr = new Timer(Timer_Tick, null, 2000, 2000);
            FindDevice();
            while(true)
            {
                ;
            }
            //
        }

        private async void FindDevice()
        {
            await GetFirstSerialPort();
            if (deviceId != string.Empty)
            {
                Debug.WriteLine("Reading from device: " + deviceId);
                // tempData.Started = true;
                
            }
        }
        
        public async void Timer_Tick(object sender)
        {

            Debug.WriteLine("Going for temp");
            var temp = dsTemp.MyHelperMethod(deviceId);

            Debug.WriteLine("Temp:  " + temp);
          
               

        }
        
        private async Task GetFirstSerialPort()
        {
            try
            {
                string aqs = SerialDevice.GetDeviceSelector();
                var dis = await DeviceInformation.FindAllAsync(aqs);
                if (dis.Count > 0)
                {
                    var deviceInfo = dis.First();
                    deviceId = deviceInfo.Id;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Unable to get serial device: " + ex.Message);
            }
        }

    }
}
